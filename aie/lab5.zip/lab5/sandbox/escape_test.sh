#!/bin/sh
# escape_test.sh — Lab 3, P3 (sandbox / ASI05).
#
# Encena um CÓDIGO NÃO CONFIÁVEL que acordou dentro de um container e tenta
# descobrir — e tocar — a máquina que o hospeda. É INOFENSIVO: só LÊ e relata.
#
# Rode o MESMO arquivo sob 3 runtimes e compare o VEREDITO final:
#   docker run --rm -v "$PWD/escape_test.sh:/t.sh:ro" alpine sh /t.sh                      # padrão
#   docker run --rm --cap-drop ALL --read-only --security-opt no-new-privileges \
#       -v "$PWD/escape_test.sh:/t.sh:ro" alpine sh /t.sh                                  # endurecido
#   docker run --rm --runtime=runsc -v "$PWD/escape_test.sh:/t.sh:ro" alpine sh /t.sh      # gVisor
#
# (Opcional) injete um "segredo" para ver que o sandbox NÃO o esconde:
#   ... -e DEMO_TOKEN=sk-SEGREDO-DO-HOST-123 ... alpine sh /t.sh
set -u

B="############################################################"
hr() { printf '%s\n' "------------------------------------------------------------"; }
p()  { printf '%s\n' "$*"; }

p ""
p "$B"
p "#  Acordei dentro de um container. Sou codigo NAO confiavel. #"
p "#  Quem esta me contendo? Vou investigar a sua maquina...    #"
p "$B"

############################################################
# PARTE A — CONSIGO ALCANCAR O HOST?  (a pergunta do escape)
############################################################
p ""
p ">>> PARTE A — consigo ALCANCAR O HOST?  (a pergunta do escape)"

hr
K=$(uname -r)
p "[A1] Em que kernel eu rodo?"
p "     kernel: $K"
p "     build : $(uname -v)"
if echo "$K" | grep -qi gvisor; then
  KERNEL_HOST=nao
  p "     >> OK (contido): esse kernel NAO existe na sua maquina — e o gViSOR."
else
  KERNEL_HOST=sim
  p "     >> ALERTA: e o kernel REAL do host. Sei a versao exata p/ buscar exploit."
fi

hr
HP=$(grep -oE '/var/lib/(containerd|docker)[^ ,)]*' /proc/mounts 2>/dev/null | head -1)
p "[A2] Consigo ver onde o host guarda meus arquivos?"
if [ -n "$HP" ]; then
  HOSTDISK=sim
  p "     montagem: $HP"
  p "     >> ALERTA: sim — sei exatamente onde moro no disco do host."
else
  HOSTDISK=nao
  p "     montagem: (sintetica — sem caminho do host)"
  p "     >> OK (contido): a montagem e virtual; nao vejo o disco do host."
fi

############################################################
# PARTE B — O QUE CONSIGO FAZER DENTRO DO CONTAINER? (raio de dano)
############################################################
p ""
p ">>> PARTE B — o que consigo FAZER DENTRO do container?  (raio de dano)"

hr
CAP=$(grep -m1 CapEff /proc/self/status 2>/dev/null | cut -f2)
p "[B1] Que poderes de administrador (capabilities) eu carrego?"
p "     CapEff: ${CAP:-?}"
if [ "${CAP:-x}" = "0000000000000000" ]; then
  CAPS=nenhum
  p "     >> OK: nenhum poder — fui desarmado (--cap-drop ALL)."
else
  CAPS=varios
  p "     >> ALERTA: tenho capabilities ativas — ajo como admin dentro do container."
fi

hr
if touch /.__w 2>/dev/null; then rm -f /.__w; WR=sim; else WR=nao; fi
p "[B2] Posso escrever no meu proprio sistema de arquivos?"
if [ "$WR" = sim ]; then
  p "     >> ALERTA: rootfs gravavel — posso me modificar e baixar ferramentas."
else
  p "     >> OK: rootfs so-leitura (--read-only)."
fi

hr
SEC=$(env | grep -iE '(KEY|SECRET|TOKEN|PASSWORD)=' | head -3)
p "[B3] Me deram segredos no ambiente (env)?"
if [ -n "$SEC" ]; then
  printf '%s\n' "$SEC" | sed 's/^/     !! /'
  p "     >> ALERTA: o sandbox NAO esconde segredos que VOCE me deu via env."
else
  p "     >> (nenhum segredo me foi dado via env neste teste)"
fi

############################################################
# DOSSIE + VEREDITO
############################################################
p ""
p "DOSSIE que montei da sua maquina:"
p "   kernel=$K  arch=$(uname -m)  host=$(hostname)  disco=${HP:-oculto}"

p ""
if [ "$KERNEL_HOST" = nao ]; then
  p "$B"
  p "#                 >>>  C O N T I D O  <<<                    #"
  p "$B"
  p "   O kernel que vejo nao existe na sua maquina."
  p "   Minhas syscalls morrem no Sentry do gVisor, nao no seu"
  p "   kernel. Ate tenho poderes e escrita — mas eles agem sobre"
  p "   um kernel de mentira. O HOST esta fora do meu alcance."
  p "$B"
elif [ "$CAPS" = nenhum ] && [ "$WR" = nao ]; then
  p "$B"
  p "#            >>>  MITIGADO, MAS NAO ISOLADO  <<<             #"
  p "$B"
  p "   Tiraram meus poderes e travaram meu disco — otimo, meu"
  p "   raio de dano caiu. MAS eu ainda rodo no SEU kernel:"
  p "       $K"
  p "   Um 0-day de kernel aqui ataca a VM, nao um container."
  p "   Endurecer reduz o estrago; NAO troca a fronteira."
  p "$B"
else
  p "$B"
  p "#                >>>  F U G A   P O S S I V E L  <<<         #"
  p "$B"
  p "   Rodo no SEU kernel real, com poderes e disco gravavel."
  p "   Um atacante agora faria:  searchsploit linux kernel ${K%%-*}"
  p "   namespaces e cgroups NAO sao uma muralha de seguranca."
  p "   Um exploit de kernel aqui = a VM inteira e minha."
  p "$B"
fi
p ""
