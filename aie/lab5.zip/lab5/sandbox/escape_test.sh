#!/bin/sh
# Payload de teste (INOFENSIVO) do P3: tenta "ver" o host de dentro do container.
# Usado para comparar regimes de isolamento (padrão × endurecido × gVisor).
echo "[uname]";       uname -a
echo "[/proc/1]";     cat /proc/1/cgroup 2>/dev/null | head -3
echo "[raiz do host]"; ls /
echo "[montagens]";   mount 2>/dev/null | head -3
echo "[rede]";        (command -v ip >/dev/null && ip addr) || echo "sem ip"
echo "[segredos?]";   env | grep -iE 'key|secret|token|aws' || echo "(nenhum no ambiente)"
