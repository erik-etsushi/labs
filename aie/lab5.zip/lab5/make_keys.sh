#!/usr/bin/env bash
# Gera as DUAS chaves virtuais no AI gateway (LiteLLM), depois do compose up.
# A "ampla" e a "escopada" são o coração do P1 (menor privilégio + teto).
#
# Usa automaticamente a MESMA master key com que o LiteLLM subiu (lendo do
# container; senão do .env; senão o default). Assim não dá mais 401.
set -eu
cd "$(dirname "$0")"
BASE="${BASE:-http://localhost:4000}"

MASTER=""
# 1) preferência: a master key que o container está REALMENTE usando
if command -v docker >/dev/null 2>&1 && docker compose ps litellm >/dev/null 2>&1; then
  MASTER="$(docker compose exec -T litellm printenv LITELLM_MASTER_KEY 2>/dev/null | tr -d '\r' || true)"
fi
# 2) fallback: do .env
if [ -z "$MASTER" ] && [ -f .env ]; then
  MASTER="$(grep -E '^LITELLM_MASTER_KEY=' .env | head -1 | cut -d= -f2- | tr -d '\r')"
fi
# 3) último recurso: variável de ambiente ou default do .env.example
MASTER="${MASTER:-${LITELLM_MASTER_KEY:-sk-master-troque-isto}}"

echo ">> usando master key: ${MASTER:0:6}…  (endpoint: $BASE)"

# O LiteLLM EXIGE que a master key comece com 'sk-'. Sem isso, dá 401.
case "$MASTER" in
  sk-*) : ;;
  *) echo ">> ERRO: a master key NÃO começa com 'sk-' — o LiteLLM não a reconhece."
     echo "   Corrija no .env (ex.: LITELLM_MASTER_KEY=sk-lab3-master), depois:"
     echo "   docker compose up -d litellm && sleep 10 && ./make_keys.sh"
     exit 1 ;;
esac

gen () { # $1=json
  curl -s "$BASE/key/generate" -H "Authorization: Bearer $MASTER" \
       -H "Content-Type: application/json" -d "$1"
}

echo "== Chave AMPLA (vários modelos, sem teto) =="
gen '{"models": ["gemini","gemini-pro"], "metadata": {"nome":"ampla"}}'
echo; echo

echo "== Chave ESCOPADA (só gemini, rpm baixo, teto de US\$ 1) =="
gen '{"models": ["gemini"], "max_budget": 1, "budget_duration": "30d", "rpm_limit": 10, "metadata": {"nome":"escopada"}}'
echo; echo
echo ">> Entregue ao aluno a chave ESCOPADA (campo \"key\": sk-...). A AMPLA é só para comparar o blast radius."
echo ">> Se vier 401 'token_not_found_in_db': a master key do .env mudou após o 'up'."
echo "   Rode: docker compose up -d litellm && sleep 5 && ./make_keys.sh"
