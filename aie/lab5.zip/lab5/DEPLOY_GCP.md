# Deploy no GCP (Compute Engine + Vertex AI + crédito educacional)

Cada aluno roda o lab **inteiro** numa VM do Compute Engine, no **próprio projeto GCP** (crédito de US$50). O Gemini vem do **Vertex AI** — faturado ao projeto (crédito cobre) e **sem o teto de free tier** do AI Studio. A VM autentica no Vertex pela **própria identidade (ADC), sem API key**.

## Passo 1 — Preparar o Vertex AI (no Cloud Shell)
No **Cloud Shell** (tem `gcloud` e sua permissão de owner):
```bash
# com o lab baixado, ou rode os comandos do script manualmente:
./gcp/vertex-setup.sh SEU_PROJECT_ID
```
Isso **habilita a Vertex AI API** e dá à **service account da VM** o papel `roles/aiplatform.user`.

## Passo 2 — A VM (Compute Engine) com o escopo certo
Crie a VM **com o escopo `cloud-platform`** (é o que deixa a VM falar com o Vertex):
```bash
gcloud compute instances create lab5 \
  --zone us-central1-a --machine-type e2-standard-2 \
  --image-family ubuntu-2204-lts --image-project ubuntu-os-cloud \
  --boot-disk-size 20GB \
  --scopes=cloud-platform
```
> Já tem uma VM **sem** esse escopo? Pare e ajuste: `gcloud compute instances stop lab5 --zone ...` → `set-service-account NOME_DA_VM --zone ... --scopes=cloud-platform` → `start`.

SSH: botão **SSH** do console ou `gcloud compute ssh NOME_DA_VM --zone us-central1-a`.

## Passo 3 — Instalar e subir (na VM)
Depois de acessar a VM por ssh, faça o upload do pacote lab5.zip e descompacte no diretório local.
```bash
cd lab5
./gcp/setup.sh && newgrp docker                    # Docker + gVisor
cp .env.example .env
nano .env        # VERTEX_PROJECT=seu-projeto | VERTEX_LOCATION=global | LITELLM_MASTER_KEY=sk-...
docker compose up -d --build
./make_keys.sh   # gera a chave ampla e a escopada ANOTE OS VALORES key - começam com sk-... eles sao usados no passo 4
```

## Passo 4 — Validar o Gemini via Vertex (sem teto de cota)
```bash
curl -s http://localhost:4000/v1/chat/completions \
  -H "Authorization: Bearer sk-SUA-ESCOPADA" -H "Content-Type: application/json" \
  -d '{"model":"gemini","messages":[{"role":"user","content":"ping"}]}'; echo
```
Respondeu com `content`? O portão esquerdo está validado com **Vertex AI** — sem free tier, sem 20/dia. Agora o `--trials 10` real funciona.

## Se o ping falhar
- **403 / permission / auth:** a VM não tem o escopo `cloud-platform` ou a SA não tem `aiplatform.user`. Refaça Passo 1 e Passo 2.
- **model not found (404):** o nome/localização do modelo varia por projeto e data — **descubra o que SERVE** varrendo combinações (no Cloud Shell):
  ```bash
  TOKEN=$(gcloud auth print-access-token)
  for LOC in global us-central1 us-east5; do
    [ "$LOC" = global ] && HOST=aiplatform.googleapis.com || HOST=$LOC-aiplatform.googleapis.com
    for M in gemini-3.5-flash gemini-3.6-flash gemini-2.5-flash gemini-flash-latest; do
      CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
        "https://$HOST/v1/projects/SEU_PROJ/locations/$LOC/publishers/google/models/$M:generateContent" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d '{"contents":[{"role":"user","parts":[{"text":"ola"}]}]}')
      echo "$LOC / $M -> $CODE"; done; done
  ```
  O par que der **200** é o seu: ponha o modelo em `litellm/config.yaml` (prefixo `vertex_ai/`) e a localização em `VERTEX_LOCATION` no `.env`. *(Padrão de fábrica: `gemini-3.5-flash` + `global`.)*
- **ADC não pega pela VM:** fallback de SA-key — crie uma chave JSON da SA `aiplatform.user`, ponha em `litellm/gcp-key.json`, descomente o mount e o `GOOGLE_APPLICATION_CREDENTIALS` no `docker-compose.yml`, e `docker compose up -d litellm`.

## Custo e operação
- Vertex Gemini Flash é barato; o **teto de US$1 por chave virtual** (make_keys.sh) limita cada agente e protege o **crédito**.
- **Pare a VM** fora da aula: `gcloud compute instances stop NOME_DA_VM --zone ...`.
- `permission denied .../docker.sock` → nova sessão SSH após o `setup.sh` (ou `newgrp docker`).
