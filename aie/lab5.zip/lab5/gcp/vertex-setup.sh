#!/usr/bin/env bash
# Prepara o Vertex AI para o Lab 5. Rode no CLOUD SHELL (tem gcloud + sua permissão de owner).
#   ./vertex-setup.sh [PROJECT_ID]
# Habilita a Vertex AI API e dá à service account da VM o papel de usar o Vertex.
set -eu
PROJECT="${1:-$(gcloud config get-value project 2>/dev/null)}"
[ -n "$PROJECT" ] || { echo "Informe o PROJECT_ID: ./vertex-setup.sh meu-projeto"; exit 1; }
echo ">> Projeto: $PROJECT"

gcloud services enable aiplatform.googleapis.com --project "$PROJECT"
NUM=$(gcloud projects describe "$PROJECT" --format='value(projectNumber)')
SA="${NUM}-compute@developer.gserviceaccount.com"
gcloud projects add-iam-policy-binding "$PROJECT" \
  --member="serviceAccount:${SA}" --role="roles/aiplatform.user" >/dev/null
echo ">> Vertex AI habilitado; papel aiplatform.user dado à SA da VM: $SA"

cat <<NOTE

PRÓXIMOS PASSOS:
1) A VM precisa do ESCOPO cloud-platform. Se ela foi criada sem ele, ajuste (VM parada):
     gcloud compute instances stop NOME_DA_INSTANCIA --zone SUA_ZONA
     gcloud compute instances set-service-account NOME_DA_INSTANCIA --zone SUA_ZONA --scopes=cloud-platform
     gcloud compute instances start  NOME_DA_INSTANCIA --zone SUA_ZONA
   (Ao criar a VM, use:  --scopes=cloud-platform  para já nascer certo.)
2) No .env da VM:  VERTEX_PROJECT=$PROJECT   VERTEX_LOCATION=global
   (se 'global' der 404 no seu projeto, descubra o par modelo×local que SERVE
    com a varredura REST do DEPLOY_GCP.md e ajuste o config.yaml + VERTEX_LOCATION)
3) docker compose up -d litellm  &&  teste o ping.

Se o ADC pela VM não funcionar, use uma SA-key (fallback): crie uma key.json desta SA,
coloque em litellm/gcp-key.json e descomente o mount no docker-compose.yml.
NOTE
