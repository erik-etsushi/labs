#!/usr/bin/env bash
# Rode UMA vez na sua VM do GCP (Compute Engine), após clonar/baixar o lab.
# Instala Docker + gVisor e te coloca no grupo docker. Idempotente.
set -eu
echo "== Lab 5 — setup na VM do Compute Engine =="

# 1) Docker + compose plugin
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER" || true

# 2) gVisor (runsc) para o P3 (a VM é real → roda de verdade)
if ! command -v runsc >/dev/null 2>&1; then
  ( set -e
    curl -fsSL https://gvisor.dev/archive.key | sudo gpg --dearmor -o /usr/share/keyrings/gvisor-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/gvisor-archive-keyring.gpg] https://storage.googleapis.com/gvisor/releases release main" | sudo tee /etc/apt/sources.list.d/gvisor.list >/dev/null
    sudo apt-get update -y && sudo apt-get install -y runsc
    sudo runsc install && sudo systemctl restart docker
  ) || echo ">> aviso: gVisor nao instalou; o P3 usa padrao x endurecido (fallback)."
fi

echo
echo ">> Docker + gVisor prontos. Agora:"
echo "   1) ABRA UMA NOVA SESSAO SSH (para valer o grupo docker), ou rode: newgrp docker"
echo "   2) cp .env.example .env  &&  edite VERTEX_PROJECT (seu projeto GCP COM billing), VERTEX_LOCATION (global) e LITELLM_MASTER_KEY (comeca com sk-)"
echo "      (Vertex autentica pela identidade da VM — NAO ha API key a preencher)"
echo "   3) docker compose up -d --build"
echo "   4) ./make_keys.sh"
