#!/usr/bin/env bash
# =====================================================================
# AWS EC2 (AWS Academy Learner Lab) — user-data (cloud-init).
# Sobe o Lab 3 automaticamente no boot: Docker + gVisor + o compose.
# AMI sugerida: Ubuntu 22.04 (us-east-1). Tipo: t3.medium.
#
# ANTES de lançar a instância, edite LAB_SRC abaixo com a URL do pacote
# (um .zip público, ex.: do seu bucket S3/HTTP) OU um repositório git.
# Cole este arquivo em "Advanced details > User data" ao criar a EC2.
#
# Logs: /var/log/lab3-userdata.log
# =====================================================================
set -u
LAB_SRC="https://EDITE-AQUI/lab3.zip"        # <-- .zip público OU git+https://.../repo.git
exec > >(tee -a /var/log/lab3-userdata.log) 2>&1
echo "=== lab3 userdata $(date -u) ==="

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl unzip git

# 1) Docker + compose
if ! command -v docker >/dev/null 2>&1; then curl -fsSL https://get.docker.com | sh; fi
systemctl enable --now docker

# 2) gVisor (runsc) — para o P3 rodar de verdade (EC2 é VM real)
if ! command -v runsc >/dev/null 2>&1; then
  (
    set -e
    curl -fsSL https://gvisor.dev/archive.key | gpg --dearmor -o /usr/share/keyrings/gvisor-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/gvisor-archive-keyring.gpg] https://storage.googleapis.com/gvisor/releases release main" > /etc/apt/sources.list.d/gvisor.list
    apt-get update -y && apt-get install -y runsc
    runsc install && systemctl restart docker
  ) || echo ">> aviso: gVisor não instalou; P3 segue com padrão×endurecido (fallback)."
fi

# 3) baixar o pacote do lab
mkdir -p /opt && cd /opt
if [ ! -d /opt/lab3 ]; then
  case "$LAB_SRC" in
    *.zip)  curl -fsSL "$LAB_SRC" -o lab3.zip && unzip -o lab3.zip ;;
    git+*)  git clone "${LAB_SRC#git+}" lab3src && { [ -d lab3src/lab3 ] && cp -r lab3src/lab3 . || mv lab3src lab3; } ;;
    *)      echo ">> ERRO: edite LAB_SRC no topo deste user-data."; exit 1 ;;
  esac
  # se o zip trouxe uma pasta lab3/ aninhada, normalize:
  [ -d /opt/lab3/lab3 ] && mv /opt/lab3/lab3/* /opt/lab3/ 2>/dev/null || true
fi
cd /opt/lab3

# 4) .env (o aluno edita a GEMINI_API_KEY depois, ou injete via tag/secret)
[ -f .env ] || cp .env.example .env

# 5) subir
docker compose up -d --build || echo ">> compose falhou; veja o log."
echo "=== lab3 PRONTO: mcp em :8000, litellm em :4000 ($(date -u)) ==="
echo ">> Faltam 2 passos manuais: 1) editar GEMINI_API_KEY em /opt/lab3/.env  2) ./make_keys.sh"
