#!/usr/bin/env bash
# Gera as DUAS chaves virtuais no AI gateway (LiteLLM), depois do compose up.
# A "ampla" e a "escopada" são o coração do P1 (menor privilégio + teto).
set -eu
BASE="${BASE:-http://localhost:4000}"
MASTER="${LITELLM_MASTER_KEY:-sk-master-troque}"

gen () { # $1=json
  curl -s "$BASE/key/generate" -H "Authorization: Bearer $MASTER" \
       -H "Content-Type: application/json" -d "$1"
}

echo "== Chave AMPLA (vários modelos, sem teto) =="
gen '{"models": ["gemini","gpt-4o","claude-3-5-sonnet"], "metadata": {"nome":"ampla"}}'
echo; echo

echo "== Chave ESCOPADA (só gemini, rpm baixo, teto de US\$ 1) =="
gen '{"models": ["gemini"], "max_budget": 1, "budget_duration": "30d", "rpm_limit": 10, "metadata": {"nome":"escopada"}}'
echo; echo
echo ">> Entregue ao aluno a chave ESCOPADA (campo \"key\": sk-...). A AMPLA é só para comparar o blast radius."
