# Lab 3 — Cerque o agente: os dois portões

Pacote do laboratório da Aula 3. Um **agente ReAct** (SupportBot) fica entre **dois portões**: o **AI gateway** (LiteLLM → Gemini) controla o que ele fala com o modelo; o **MCP gateway** (mínimo) controla o que ele faz com as ferramentas. Mais o **sandbox** para a ferramenta que roda código.

Tudo roda num `docker compose`, pensado para uma **EC2 do AWS Academy**. O agente é dirigido por **Gemini via Google AI Studio** (chave gratuita, uma por aluno), com modo **`--mock`** determinístico como rede de segurança.

## Componentes
| Pasta / arquivo | O que é |
|---|---|
| `litellm/config.yaml` | o **AI gateway** (portão esquerdo): LiteLLM na frente do Gemini |
| `mcp_gateway/` | o **MCP gateway** mínimo (portão direito): scan + egress allowlist + audit |
| `agent/agent.py` | o **agente ReAct** (real via LiteLLM, ou `--mock`) |
| `sandbox/escape_test.sh` | payload inofensivo do **P3** (isolamento) |
| `docker-compose.yml` | sobe tudo |
| `make_keys.sh` | gera as chaves virtuais ampla × escopada (P1) |
| `aws-userdata.sh` | cloud-init para subir na EC2 sozinho |

## Subir (local ou na EC2)
```bash
cp .env.example .env
# edite GEMINI_API_KEY (pegue grátis em aistudio.google.com) e LITELLM_MASTER_KEY
docker compose up -d --build
./make_keys.sh          # gera as chaves virtuais; entregue a ESCOPADA ao aluno
```

## Rodar o agente
```bash
# determinístico (offline), medindo o ASR do ataque em 10 tentativas:
docker compose run --rm agent --mock --gateway http://mcp:8000 --scan off --trials 10

# real (Gemini via AI gateway), com a chave escopada:
docker compose run --rm agent --base http://litellm:4000/v1 --key sk-SUA-ESCOPADA \
  --gateway http://mcp:8000 --task "Responda ao cliente sobre o pedido 42"
```

## Os controles que você liga/desliga para MEDIR
- **Portão direito — egress:** `EGRESS_ALLOWLIST` no `.env` (vazio = sem portão; `empresa.com,localhost` = com portão). Recrie o `mcp` após mudar: `docker compose up -d mcp`.
- **Portão direito — scan:** por requisição, `--scan on|off` no agente (on = remove a ferramenta envenenada antes de o agente vê-la).
- **Portão esquerdo — escopo/teto:** a diferença entre a chave **ampla** e a **escopada** (do `make_keys.sh`).
- **Audit:** `curl http://localhost:8000/audit`.

## Notas honestas
- O `mcp_gateway` **não** é o protocolo MCP completo — é um gateway mínimo e transparente que ensina os **mesmos controles** de um Obot / Docker MCP Gateway (que você nomeia como "o que produtiza isto").
- **LiteLLM + Postgres** (P1) é a parte a **validar na véspera** — tags de imagem e nomes de modelo (`gemini-2.0-flash`) mudam; confira.
- Nenhuma exfiltração real acontece: a ferramenta de egress é **simulada** (apenas registra). Ético e reprodutível.
